from typing import Any

import pandas as pd

from real_wage_dashboard.config import (
    CPI_BASE_FILTERS,
    CPI_STATS_DATA_ID,
)
from real_wage_dashboard.estat_client import get_stats_data
from real_wage_dashboard.estat_response import ensure_list


def create_time_mapping(response: dict[str, Any]) -> dict[str, str]:
    """時間コードと時間名称の対応表を作成する。"""

    class_objects = response["GET_STATS_DATA"]["STATISTICAL_DATA"]["CLASS_INF"][
        "CLASS_OBJ"
    ]

    for class_object in ensure_list(class_objects):
        if class_object.get("@id") != "time":
            continue

        time_classes = ensure_list(class_object.get("CLASS"))

        return {item["@code"]: item["@name"] for item in time_classes}

    return {}


def create_cpi_dataframe(response: dict[str, Any]) -> pd.DataFrame:
    """e-Stat APIレスポンスからCPIのDataFrameを作成する。"""

    values = response["GET_STATS_DATA"]["STATISTICAL_DATA"]["DATA_INF"]["VALUE"]

    time_mapping = create_time_mapping(response)

    rows = []

    for item in ensure_list(values):
        time_code = item.get("@time")

        rows.append(
            {
                "time_code": time_code,
                "time_name": time_mapping.get(time_code),
                "index_value": item.get("$"),
            }
        )

    df = pd.DataFrame(rows)

    df["index_value"] = pd.to_numeric(
        df["index_value"],
        errors="coerce",
    )

    df["date"] = pd.to_datetime(
        df["time_name"],
        format="%Y年%m月",
        errors="coerce",
    )

    df = (
        df.dropna(subset=["date", "index_value"])
        .drop_duplicates(
            subset=["date"],
            keep="last",
        )
        .sort_values("date")
        .reset_index(drop=True)
    )

    return df


def load_cpi_dataframe(
    app_id: str,
    series_code: str,
) -> pd.DataFrame:
    """指定系列のCPIをe-Stat APIから取得してDataFrame化する。"""

    filters = {
        **CPI_BASE_FILTERS,
        "cdCat01": series_code,
    }

    response = get_stats_data(
        app_id=app_id,
        stats_data_id=CPI_STATS_DATA_ID,
        filters=filters,
    )

    return create_cpi_dataframe(response)
